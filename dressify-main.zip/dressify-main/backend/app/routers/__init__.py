# Routers package
from .search import router as search_router
