# Core configuration module
from .config import config, Config
